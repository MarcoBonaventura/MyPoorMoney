package com.example.mypoormoney;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ListView;
import android.view.View.OnClickListener;
import android.database.Cursor;
import android.content.Context;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";

    private DbManager db = null;
    private CursorAdapter adapter;
    private ListView listview = null;
    private OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v)
        {
            int position = listview.getPositionForView(v);
            long id = adapter.getItemId(position);
            if (db.delete(id))
                adapter.changeCursor(db.query());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DbManager(this);
        listview = (ListView) findViewById(R.id.listview);
        Cursor crs = db.query();
        adapter = new CursorAdapter(this, crs, 0) {
            @Override
            public View newView(Context ctx, Cursor arg1, ViewGroup arg2) {
                View v = getLayoutInflater().inflate(R.layout.listactivity_row, null);
                return v;
            }

            @Override
            public void bindView(View v, Context arg1, Cursor crs) {
                String oggetto = crs.getString(crs.getColumnIndex(DatabaseStrings.FIELD_SUBJECT));
                String data = crs.getString(crs.getColumnIndex(DatabaseStrings.FIELD_DATE));
                TextView txt = (TextView) v.findViewById(R.id.txt_subject);
                txt.setText(oggetto);
                txt = (TextView) v.findViewById(R.id.txt_date);
                txt.setText(data);
                ImageButton imgbtn = (ImageButton) v.findViewById(R.id.btn_delete);
                imgbtn.setOnClickListener(clickListener);
            }

            @Override
            public long getItemId(int position) {
                Cursor crs = adapter.getCursor();
                crs.moveToPosition(position);
                return crs.getLong(crs.getColumnIndex(DatabaseStrings.FIELD_ID));
            }
        };

        listview.setAdapter(adapter);
    }

    public void salva(View v) {
        EditText sub = (EditText) findViewById(R.id.oggetto);
        EditText txt = (EditText) findViewById(R.id.testo);
        EditText date = (EditText) findViewById(R.id.data);
        if (sub.length() >0 && date.length() >0)
        {
            db.save(sub.getEditableText().toString(), txt.getEditableText().toString(), date.getEditableText().toString());
            adapter.changeCursor(db.query());
        }
    }

    public void sendMessage(View view) {
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        EditText editText = (EditText) findViewById(R.id.editText2);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }






}
