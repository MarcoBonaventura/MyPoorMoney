package com.example.mypoormoney;

public class DatabaseStrings {

    public static final String FIELD_ID="_id";
    public static final String FIELD_SUBJECT="oggetto";
    public static final String FIELD_TEXT="testo";
    public static final String FIELD_DATE="data";
    public static final String TBL_NAME="Scadenze";

}
